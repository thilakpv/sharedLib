#!/usr/bin/env sh
#
# CIS-LBK Cloud Team Built Recommendation Function
# ~/CIS-LBK/functions/fct/nix_ensure_permissions_crontab_configured_fct.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       09/21/20    Recommendation "Ensure permissions on /etc/crontab are configured"
#
ensure_permissions_crontab_configured_fct()
{

	echo
	echo "**** $RN $RNA"
	chmod u-x,go-rwx /etc/crontab
	chown root:root /etc/crontab

	return "${XCCDF_RESULT_PASS:-201}"

}