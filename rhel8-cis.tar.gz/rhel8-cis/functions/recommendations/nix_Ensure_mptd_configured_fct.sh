#!/usr/bin/env sh
#
# CIS-LBK Cloud Team Built Recommendation Function
# ~/CIS-LBK/functions/fct/nix_Ensure_mptd_configured_fct.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       09/21/20    Recommendation "Ensure message of the day is configured properly"
#
nix_Ensure_mptd_configured_fct()
{
	# Ensure message of the day is configured properly
	echo
	echo \*\*\*\* Ensure\ message\ of\ the\ day\ is\ configured\ properly
	sed -ri 's/(\\v|\\r|\\m|\\s)//g' /etc/motd

	return "${XCCDF_RESULT_PASS:-201}" 

}