BANR()
{
	echo ""
	echo ""
	echo "     ######################################################## "
	echo "     #  CIS Linux Build Kit for centOS Linux 7              # "
	echo "     #  This Linux Build Kit works in conjunction with the  # "
	echo "     #  CIS centOS Linux 7 Benchmark v3.0.0                 # "
	echo "     #  This script is the property of:                     # "
	echo "     #  Center for Internet Security (CIS)                  # "
	echo "     ######################################################## "
	echo ""
	echo ""
}
# End of print bannor to Screen